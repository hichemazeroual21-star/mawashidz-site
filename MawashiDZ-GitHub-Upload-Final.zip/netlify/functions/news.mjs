const QUERY_GROUPS = [
  { category: "livestock", q: '(المواشي OR الأغنام OR الأبقار OR élevage OR ovins OR bovins) Algérie' },
  { category: "feed", q: '(الأعلاف OR الشعير OR التبن OR aliments de bétail OR fourrage) Algérie' },
  { category: "vet", q: '(بيطري OR vétérinaire OR vaccination OR santé animale OR fièvre aphteuse) Algérie' },
  { category: "official", q: '(وزارة الفلاحة OR قرار OR دعم المربين OR importation bétail) Algérie' },
  { category: "weather", q: '(أمطار OR جفاف OR نشرة جوية OR météo OR BMS) Algérie agriculture' }
];

const TRUSTED_SOURCES = [
  { match: ["وكالة الأنباء الجزائرية", "Algérie Presse Service", "APS"], tier: "official" },
  { match: ["وزارة الفلاحة", "Ministère de l'Agriculture"], tier: "official" },
  { match: ["الجريدة الرسمية", "Journal Officiel"], tier: "official" },
  { match: ["الإذاعة الجزائرية", "Radio Algérienne"], tier: "official" },
  { match: ["التلفزيون الجزائري", "Télévision Algérienne"], tier: "official" },
  { match: ["AL24 News"], tier: "official" },
  { match: ["الشروق", "Echorouk"], tier: "media" },
  { match: ["الخبر", "El Khabar"], tier: "media" },
  { match: ["النهار", "Ennahar"], tier: "media" },
  { match: ["البلاد", "El Bilad"], tier: "media" },
  { match: ["TSA Algérie", "TSA عربي", "Tout sur l'Algérie"], tier: "media" },
  { match: ["El Watan"], tier: "media" },
  { match: ["Le Soir d'Algérie"], tier: "media" },
  { match: ["Dzair News", "دزاير نيوز"], tier: "media" }
];

const RELEVANT_TERMS = [
  "مواشي","أغنام","أبقار","ماعز","عجول","علف","أعلاف","شعير","تبن",
  "بيطري","تلقيح","حمى قلاعية","فلاحة","جفاف","أمطار",
  "élevage","ovin","bovin","bétail","fourrage","vétérinaire","vaccination",
  "agriculture","météo","sécheresse"
];

function decodeXml(text = "") {
  return text
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function pick(block, tag) {
  const m = block.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, "i"));
  return m ? decodeXml(m[1]) : "";
}

function classifySource(source = "") {
  const clean = source.trim().toLowerCase();
  for (const entry of TRUSTED_SOURCES) {
    if (entry.match.some(name => clean.includes(name.toLowerCase()))) return entry.tier;
  }
  return null;
}

function relevant(title = "", summary = "") {
  const text = `${title} ${summary}`.toLowerCase();
  return RELEVANT_TERMS.some(term => text.includes(term.toLowerCase()));
}

function parseFeed(xml, category) {
  const blocks = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/gi)].map(m => m[1]);
  return blocks.map(block => {
    const title = pick(block, "title");
    const url = pick(block, "link");
    const summary = pick(block, "description").slice(0, 280);
    const published = pick(block, "pubDate");
    const source = pick(block, "source");
    const trust = classifySource(source);
    return {
      category, title, url, summary, source, trust,
      trustLabel: trust === "official" ? "رسمي" : "مصدر إعلامي موثوق",
      published,
      publishedLabel: published ? new Date(published).toLocaleString("ar-DZ", { dateStyle: "medium", timeStyle: "short" }) : ""
    };
  }).filter(item => item.title && item.url && item.source && item.trust && relevant(item.title, item.summary));
}

export default async () => {
  try {
    const results = [];
    for (const group of QUERY_GROUPS) {
      const rssUrl = `https://news.google.com/rss/search?q=${encodeURIComponent(group.q)}&hl=ar&gl=DZ&ceid=DZ:ar`;
      const response = await fetch(rssUrl, { headers: { "user-agent": "MawashiDZ-News/1.0" } });
      if (!response.ok) continue;
      results.push(...parseFeed(await response.text(), group.category));
    }
    const seen = new Set();
    const items = results.filter(item => {
      const key = item.title.toLowerCase().replace(/\s+/g, " ").trim();
      if (seen.has(key)) return false;
      seen.add(key); return true;
    }).sort((a, b) => {
      const tierA = a.trust === "official" ? 0 : 1;
      const tierB = b.trust === "official" ? 0 : 1;
      if (tierA !== tierB) return tierA - tierB;
      return new Date(b.published || 0) - new Date(a.published || 0);
    }).slice(0, 30);

    return new Response(JSON.stringify({ items, updatedAt: new Date().toISOString(), policy: "strict_allowlist" }), {
      headers: {
        "content-type": "application/json; charset=utf-8",
        "cache-control": "public, max-age=60, s-maxage=60",
        "access-control-allow-origin": "*"
      }
    });
  } catch (error) {
    return new Response(JSON.stringify({ items: [], error: "news_unavailable" }), {
      status: 200,
      headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
    });
  }
};
